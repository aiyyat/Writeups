insert into users (username,password,enabled) values ('user1@example.com','user1',1);
insert into users (username,password,enabled) values ('admin1@example.com','admin1',1);
insert into users (username,password,enabled) values ('user2@example.com','admin1',1);
insert into users (username,password,enabled) values ('disabled1@example.com','disabled1',0);