insert into authorities(username,authority) values ('user1@example.com','ROLE_USER');
insert into authorities(username,authority) values ('admin1@example.com','ROLE_ADMIN');
insert into authorities(username,authority) values ('admin1@example.com','ROLE_USER');
insert into authorities(username,authority) values ('user2@example.com','ROLE_USER');
insert into authorities(username,authority) values ('disabled1@example.com','ROLE_USER');